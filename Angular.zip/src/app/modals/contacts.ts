export class contacts {
    id: number
    name: string
    description: string
    email: string
    phoneNumber: string
    relationship: string
    groupName: string
    groupDescription: string
    groupMaxLimit: number
    isBlocked: number
    groupId: number
    isImportant: number
    groupComments: string
    createdOn: string
}

export class speedDialContacts extends  contacts{
    keyword: number
}