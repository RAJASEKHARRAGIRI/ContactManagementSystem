export class groups {
    id: number
    name: string
    description: string
    maxLimit: number
    comments: string
    createdOn: string
}