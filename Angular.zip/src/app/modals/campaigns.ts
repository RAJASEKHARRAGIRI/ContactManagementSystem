export class campaigns {
    campaignId: number
    campaignName: string
    campaignType: number
    contactId: number
    contactName: string
    contactEmail: string
    phoneNumber: string
    groupName: string
    emailSubject: string
    emailTemplate: string
    emailIsSent: number
    campaignRunOn: string
}