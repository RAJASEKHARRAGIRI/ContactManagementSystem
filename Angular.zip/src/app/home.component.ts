import {
  Component
} from '@angular/core';
import { Title } from '@angular/platform-browser';
// import { SkyWaitService } from '@skyux/indicators';
import { SkyToastService, SkyToastType } from '@skyux/toast';
import { contacts } from './modals/contacts';
import { groups } from './modals/groups';
import { ContactService } from './service/contact.service';
import { GroupService } from './service/group.service';

@Component({
  selector: 'my-home',
  templateUrl: './home.component.html',
  styleUrls: ['./styles.css']
})
export class HomeComponent {
  public name = 'Contact Management System';
  contactTypes: any = [
    {'name':'Cloud','icon':'cloud'},
    {'name':'Email','icon':'envelope-o'},
    {'name':'Call','icon':'phone'},
    {'name':'Notify','icon':'bell-o'},
  ];

  
  public isWaiting: boolean = true;
  constructor(
    // private waitSvc: SkyWaitService,
    private groupService: GroupService,
    private toastService: SkyToastService,
    private contactService: ContactService,
    private titleService: Title
  ) { 
    // this.waitSvc.beginBlockingPageWait();
    // setTimeout(() => {
    //   this.waitSvc.endBlockingPageWait();
    // }, 2000);
    
   this.getData();
   this.getContactsData(0,0,0,0);
  }

  ngOnInit() {
    this.titleService.setTitle("Home - Contact Management System");
  }

  // isWaiting: boolean = true;
  groupsData: groups[] = [];
  groupsCount :number = 0;
  getData() {
    this.groupsData = [];
    this.groupService.getAllGroups()
      .subscribe(res => {
        this.groupsData = res;
        if(this.groupsData ){
          this.groupsCount = this.groupsData.length;
        }
        setTimeout(() => {
          this.isWaiting = false;
        }, 2000);
      },
      err => {
        setTimeout(() => {
          this.isWaiting = false;
        }, 2000);
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
  }
  contactsData: contacts[] = [];
  blockedContactsCount: number = 0;
  totalContactsCount: number = 0;
  impContactsCount: number = 0;
  getContactsData(isRecentTop: number, isBlock: number, isImp: number, isActive: number) {
    this.contactsData = [];
    this.totalContactsCount = 0;
    this.blockedContactsCount = 0;
    this.impContactsCount = 0;
    let payload = {
      "IsRecentTop": isRecentTop,
      "IsBlocked": isBlock,
      "IsImportant": isImp,
      "IsActive": isActive
    }
    this.isWaiting = true;
    this.contactService.getAllContacts(payload)
      .subscribe(res => {
        this.contactsData = res;
        for (let contact of this.contactsData) {
          this.totalContactsCount += 1;
          if (contact.isBlocked == 1)
            this.blockedContactsCount++;
          if (contact.isImportant == 1)
            this.impContactsCount++;
        }
        setTimeout(() => {
          this.isWaiting = false;
        }, 2000);
      },
        err => {
          setTimeout(() => {
            this.isWaiting = false;
          }, 2000);
          this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
        })
  }

  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  
}
