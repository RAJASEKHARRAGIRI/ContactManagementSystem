import {
  Component
} from '@angular/core';

import { DatePipe } from '@angular/common';
// import { Title } from '@angular/platform-browser';
@Component({
  selector: 'app-nav',
  templateUrl: './app-nav.component.html',
  styleUrls: ['./app-nav.component.scss'],
  providers: [
    DatePipe
  ]
})
export class AppNavComponent {

  public nav = [
    {
      titleKey: 'app_nav_home',
      path: '/',
      icon: 'fa fa-home'
    },
    {
      titleKey: 'app_nav_groups',
      path: '/groups',
      icon: 'fa fa-users'
    },
    {
      titleKey: 'app_nav_contacts',
      path: '/contacts',
      icon: 'fa fa-address-book-o'
    },
    {
      titleKey: 'app_nav_campaign',
      path: '/campaign',
      icon: 'fa fa-bell'
    },
  ];
  myDate = "";
  constructor(private datePipe: DatePipe,
    // private titleService: Title
    ) {
    this.myDate = this.datePipe.transform(new Date(), 'MMM d, y, h:mm:ss a');
  }

  ngOnInit() {
    // this.titleService.setTitle("Contact Management System");
  }
}
