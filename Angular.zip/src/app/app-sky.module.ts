import { CommonModule } from '@angular/common';
import {
  NgModule
} from '@angular/core';
import { FormsModule } from '@angular/forms';

import {
  SkyAvatarModule
} from '@skyux/avatar';
import { SkyCheckboxModule } from '@skyux/forms';

import {
  SkyAlertModule,
  SkyIconModule,
  SkyKeyInfoModule,
  SkyLabelModule,
  SkyWaitModule,
  SkyStatusIndicatorModule
} from '@skyux/indicators';

import {
  SkyFluidGridModule, SkyPageSummaryModule,SkyDescriptionListModule
} from '@skyux/layout';

import {
  SkyNavbarModule
} from '@skyux/navbar';

import { BrowserModule,Title } from '@angular/platform-browser';
import {
  SkyGridModule
} from '@skyux/grids';
import { SkyThemeService } from '@skyux/theme';
import { SkyAppLocaleProvider } from '@skyux/i18n';
import {
  of as observableOf
} from 'rxjs';
import {
  SkyVerticalTabsetModule
} from '@skyux/tabs';

import {
  RouterModule
} from '@angular/router';


import {
  SkyRadioModule
} from '@skyux/forms';

import {
  SkyListModule,
  SkyListToolbarModule
} from '@skyux/list-builder';

import {
  SkyListViewChecklistModule
} from '@skyux/list-builder-view-checklist';
import {
  SkyDropdownModule
} from '@skyux/popovers';
import {
  SkyDefinitionListModule
} from '@skyux/layout';
import {
  ReactiveFormsModule
} from '@angular/forms';
import {
  SkyInputBoxModule
} from '@skyux/forms';
import {
  SkySummaryActionBarModule
} from '@skyux/action-bars';
import {
  SkyRepeaterModule
} from '@skyux/lists';
import {
  SkySplitViewModule
} from '@skyux/split-view';
import {
  SkyConfirmModule
} from '@skyux/modals';
import { SkyToastModule } from '@skyux/toast';
import {
  SkyIdModule
} from '@skyux/core';
import {
  SkyModalModule
} from '@skyux/modals';

import {
  AddContactComponent
} from './contacts/add-contact.component';
import {
  ContactListPopupComponent
} from './contacts/contact-list-popup.component';


import {
  SkyListViewGridModule
} from '@skyux/list-builder-view-grids';

import {
  SkyPopoverModule
} from '@skyux/popovers';

import {
  SkyFileAttachmentsModule
} from '@skyux/forms';
import { UploadContactsComponent } from './contacts/upload-contacts.component';
import {
  SkyProgressIndicatorModule
} from '@skyux/progress-indicator';

import { CKEditorModule } from 'ckeditor4-angular';
import {
  SkyAutocompleteModule
} from '@skyux/lookup';
import { CampaignListPopupComponent } from './campaign/campaign-list-popup.component';

@NgModule({
  imports: [
    
    SkyAutocompleteModule,
    CKEditorModule,
    SkyPopoverModule,
    BrowserModule,
    SkyGridModule,
    RouterModule.forRoot([]),
    SkyVerticalTabsetModule,
    SkyListViewChecklistModule,
    SkyListModule,
    SkyListToolbarModule,
    SkyRadioModule,
    SkyDropdownModule,
    SkySummaryActionBarModule,
    SkyConfirmModule,
    SkySplitViewModule,
    SkyDefinitionListModule,
    SkyInputBoxModule,
    SkyToastModule,
    SkyModalModule,
    SkyIdModule,
    SkyListViewGridModule,
    SkyFileAttachmentsModule,
    SkyProgressIndicatorModule,
    SkyWaitModule
  ],
  exports: [
    
    CKEditorModule,
    SkyAutocompleteModule,
    SkyAvatarModule,
    SkyAlertModule,
    SkyKeyInfoModule,
    SkyFluidGridModule,
    SkyNavbarModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SkyPageSummaryModule,
    SkyDescriptionListModule,
    SkyAlertModule,
    SkyAvatarModule,
    SkyCheckboxModule,
    SkyLabelModule,
    SkyKeyInfoModule,
    SkyIconModule,
    SkyWaitModule,
    SkyStatusIndicatorModule,
    SkyGridModule,
    SkyVerticalTabsetModule,
    SkyListViewChecklistModule,
    SkyListModule,
    SkyListToolbarModule,
    SkyRadioModule,
    SkyDropdownModule,
    SkySummaryActionBarModule,
    SkyRepeaterModule,
    SkyConfirmModule,
    SkySplitViewModule,
    SkyDefinitionListModule,
    SkyInputBoxModule,
    SkyToastModule,
    SkyModalModule,
    SkyIdModule,
    SkyPopoverModule,
    SkyListViewGridModule,
    SkyFileAttachmentsModule,
    SkyProgressIndicatorModule
  ],
  declarations: [
    
  ],
  entryComponents: [
    AddContactComponent,
    ContactListPopupComponent,
    UploadContactsComponent,
    CampaignListPopupComponent,
    
  ],
  providers: [
    Title,
    SkyThemeService,
    {
      provide: SkyAppLocaleProvider,
      useValue: {
        getLocaleInfo: () => observableOf({
          locale: 'en-US'
        })
      }
    }
  ],
  
})
export class AppSkyModule { }
