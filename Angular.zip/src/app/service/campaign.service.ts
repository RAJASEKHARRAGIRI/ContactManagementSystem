import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { campaigns } from '../modals/campaigns';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class CampaignService {

    apiUrl = "http://localhost:45873/api/";
   
    constructor(private http: HttpClient) { 

    }

    RunEmailCampaign(payload: any) {
        return this.http.post<any>(this.apiUrl + 'Campaign/RunCampaign/', payload);
    }

    getAllCampaignDetails(){
        return this.http.get<campaigns[]>(this.apiUrl + 'Campaign/GetAllCampaignDetails/');
    }

    private currentCampaignData = new BehaviorSubject<any>("");
    getCampaignsData = this.currentCampaignData.asObservable()
    shareCampaignsDataList(currentState: any):any{
      this.currentCampaignData.next(currentState); 
    }

 
  
     
}
