import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { contacts, speedDialContacts } from '../modals/contacts';
import { BehaviorSubject } from 'rxjs';


@Injectable({
    providedIn: 'root'
})
export class ContactService {

    apiUrl = "http://localhost:45873/api/";
    constructor(private http: HttpClient) { 

    }

    addContact(payload: any) {
        return this.http.post<any>(this.apiUrl + 'Contacts/AddContact/', payload);
    }

    
    updateContact(payload: any) {
        return this.http.post<any>(this.apiUrl + 'Contacts/UpdateContact/', payload);
    }

    getAllContacts(payload: any){
        return this.http.post<contacts[]>(this.apiUrl + 'Contacts/GetAllContacts/', payload);
    }
    deleteContactOnId(contactId: number){
        return this.http.delete<any>(this.apiUrl + 'Contacts/DeleteContact/'+contactId);
    }

    updateSpeedDialContact(payload: any) {
        return this.http.post<any>(this.apiUrl + 'Contacts/UpdateSpeedDialContact/', payload);
    }

    getAllSpeedDialContacts() {
        return this.http.get<speedDialContacts[]>(this.apiUrl + 'Contacts/GetAllSpeedDialContacts/');
    }

    public AddContactSynchronous(payload:any): Promise<any>{
        return this.http.post<any>(this.apiUrl + 'Contacts/AddContact/', payload).toPromise();
    }

    private currentState = new BehaviorSubject<any>("");
    contactOpertationStatus = this.currentState.asObservable()
    afterCompleteOperationKnowTheStatus(currentState: any):any{
      this.currentState.next(currentState); 
    }

    private currentSpeedDialState = new BehaviorSubject<any>("");
    contactSpeedDialStatus = this.currentSpeedDialState.asObservable()
    afterCompleteOperationKnowTheSpeedDialStatus(currentState: any):any{
      this.currentSpeedDialState.next(currentState); 
    }
}
