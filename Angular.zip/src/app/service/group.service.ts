import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { groups } from '../modals/groups';


@Injectable({
    providedIn: 'root'
})
export class GroupService {

    apiUrl = "http://localhost:45873/api/";
    constructor(private http: HttpClient) { 

    }

    addGroup(payload: any) {
        return this.http.post<any>(this.apiUrl + 'Groups/AddGroup/', payload);
    }

    updateGroup(payload: any) {
        return this.http.post<any>(this.apiUrl + 'Groups/UpdateGroup/', payload);
    }

    getAllGroups(){
        return this.http.get<groups[]>(this.apiUrl + 'Groups/GetAllGroup/');
    }
    deleteGroupOnId(groupId: number){
        return this.http.delete<any>(this.apiUrl + 'Groups/DeleteGroup/'+groupId);
    }
}
