import {
  Component
} from '@angular/core';


import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
// import { SkyWaitService } from '@skyux/indicators';

import {
  SkyConfirmButtonAction,
  // SkyConfirmInstance,
  // SkyConfirmCloseEventArgs,
  SkyConfirmService,
  // SkyConfirmType,
  // SkyConfirmType
} from '@skyux/modals';

import {
  SkySplitViewMessage,
  // SkySplitViewMessageType
} from '@skyux/split-view';

import {
  Subject
} from 'rxjs';
import { SkyToastService, SkyToastType } from '@skyux/toast';
import { GroupService } from '../service/group.service';
import { groups } from '../modals/groups';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-manage-groups',
  templateUrl: './manage-groups.component.html',
  styleUrls: ['./manage-groups.component.scss']
})
export class ManageGroupsComponent {

  isWaiting: boolean = false;
  public avatarUrl: string | File = 'https://icon-library.com/images/group-icon/group-icon-7.jpg';
  public set activeIndex(value: number) {
    this._activeIndex = value;
    this.activeRecord = this.groupsData[this._activeIndex];
    this.loadFormGroup(this.activeRecord);
  }

  public get activeIndex(): number {
    return this._activeIndex;
  }

  public activeRecord: any;



  public listWidth: number;

  public splitViewDemoForm: FormGroup;

  public splitViewStream = new Subject<SkySplitViewMessage>();

  private _activeIndex = 0;

  constructor(
    public confirmService: SkyConfirmService,
    // private waitSvc: SkyWaitService,
    private toastService: SkyToastService,
    private groupService: GroupService,
    private fb: FormBuilder,
    private titleService: Title
  ) {
    // Start with the first item selected.
    this.activeIndex = 0;
    // this.waitSvc.beginBlockingPageWait();
    // setTimeout(() => {
    //   this.waitSvc.endBlockingPageWait();
    // }, 1000);
    
    this.getData();
  }
  ngOnInit() {
    this.titleService.setTitle("Groups - Contact Management System");
  }

  groupsData: groups[] = [];
  getData() {
    this.isWaiting = true;
    this.groupsData = [];
    this.groupService.getAllGroups()
      .subscribe(res => {
        this.groupsData = res;
       
         setTimeout(() => {
          this.isWaiting = false;
          }, 1000);
      },
      err => {
        setTimeout(() => {
          this.isWaiting = false;
        }, 1000);
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
  }


  deleteGroup(data: groups): void {

  }

  public selectedAction: SkyConfirmButtonAction;
  public selectedText: string;
  public deleteGroupConfirmation(data: groups) {
    if (confirm('Are you sure you want to delete this "'+data.name+'" group?')) {
      this.groupService.deleteGroupOnId(data.id)
      .subscribe(res => {
        if(res && res.isSuccess ){
          this.openToast(data.name+" "+res.message, SkyToastType.Success);
        }else{
          this.openToast(data.name+" "+res.message, SkyToastType.Danger);
        }
        this.clearForm();
        this.getData();
      }, err => {
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
    } else {
      return;
    }
  }

  currentGroup: groups ;
  isUpdate: boolean = false;
  public onItemClick(data: groups): void {
      this.currentGroup = data;
      this.isUpdate = true;
      
      this.splitViewDemoForm.get('name').setValue(data.name);
      this.splitViewDemoForm.get('desc').setValue(data.description);
      this.splitViewDemoForm.get('limit').setValue(data.maxLimit);
      this.splitViewDemoForm.get('comments').setValue(data.comments);
  }
  AddFormInitiate(){
    this.currentGroup = <groups>{};
    this.isUpdate = false;
    this.clearForm()
  }

  public UpdateForm() {
    let payload = {
      "Id": this.currentGroup.id,
      "Name": this.splitViewDemoForm.value.name,
      "Description": this.splitViewDemoForm.value.desc,
      "MaxLimit": this.splitViewDemoForm.value.limit,
      "Comments": this.splitViewDemoForm.value.comments
    }
    this.groupService.updateGroup(payload)
      .subscribe(res => {
        if(res && res.isSuccess ){
          this.openToast(res.message, SkyToastType.Success);
        }else{
          this.openToast(res.message, SkyToastType.Danger);
        }
        this.clearForm();
        this.getData();
      }, err => {
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
  }


  public onApprove() {
    const controls = this.splitViewDemoForm.controls;
    /** check form */
    if (this.splitViewDemoForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );
      this.openToast("Required mandatory fields", SkyToastType.Warning);
      return;
    }
    this.saveForm();
  }

  public clearForm() {
    this.splitViewDemoForm.reset();
    this.loadFormGroup('test');
    this.isUpdate=false;
    this.currentGroup = <groups>{};
  }
  public onDeny(): void {
    console.log('Denied clicked!');
  }

  private loadFormGroup(record: any): void {
    this.splitViewDemoForm = this.fb.group({
      name: ['', [Validators.required]],
      limit: ['', [Validators.required]],
      desc: ['', [Validators.required]],
      comments: [''],
    });

  }

  private saveForm(): void {
    let payload = {
      "Id": 0,
      "Name": this.splitViewDemoForm.value.name,
      "Description": this.splitViewDemoForm.value.desc,
      "MaxLimit": this.splitViewDemoForm.value.limit,
      "Comments": this.splitViewDemoForm.value.comments
    }
    this.groupService.addGroup(payload)
      .subscribe(res => {
        if(res && res.isSuccess ){
          this.openToast(res.message, SkyToastType.Success);
        }else{
          this.openToast(res.message, SkyToastType.Danger);
        }
        this.clearForm();
        this.getData();
      }, err => {
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
  }

  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.splitViewDemoForm.controls[controlName];
    if (!control) {
      return false;
    }

    const result = control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }
}
