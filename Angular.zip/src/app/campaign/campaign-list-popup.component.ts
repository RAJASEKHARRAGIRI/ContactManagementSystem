
import {
  Component
} from '@angular/core';
import {  SkyModalInstance } from '@skyux/modals';
import { SkyToastService, SkyToastType } from '@skyux/toast';
import { campaigns } from '../modals/campaigns';
import { CampaignService } from '../service/campaign.service';


@Component({
  selector: 'app-campaign-list-popup',
  templateUrl: './campaign-list-popup.component.html',
  styleUrls: ['./campaign-list-popup.component.scss']
})
export class CampaignListPopupComponent {

  constructor(
    public instance: SkyModalInstance,
    private campService: CampaignService,
    private toastService: SkyToastService,
   
  ) { 

  }
  data:any[] = [];
  selectedKeyword : number = 0;
  campaignDetails: campaigns[] = [];
  ngOnInit() {
    this.campService.getCampaignsData.subscribe((value:any) => {
      if(value.campaignsData){
        this.campaignDetails = value.campaignsData;
      }
    });
  }

  closePopup(){
    this.instance.close()
  }

  getContactInfo(contactId: number, propertyName: string) {

    let obj = this.campaignDetails.filter(obj => obj.contactId == contactId);
    if (propertyName == 'group')
      return obj[0].groupName;
    else if (propertyName == 'email')
      return obj[0].contactEmail;
    else if (propertyName == 'name')
      return obj[0].contactName;
    else if (propertyName == 'phone')
      return obj[0].phoneNumber;
  }

 
  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  previewTemplate(campId:number){       
    let obj = this.campaignDetails.filter(obj => obj.campaignId == campId)[0];
    var newWin = open('url','windowName','height=600,width=1000,top=50, left=150');
    let temp = obj.emailTemplate.replace("{contactname}", obj.contactName);
    let tempStr = '<center><p><h3><u>Email Preview</u></h3></p></center><p><h4>Email Subject: </h4>'+obj.emailSubject+'</p><p><h4>Email Body: </h4></p>';
    newWin.document.write("<div style='overflow: scroll;max-height: 600px;'>"+tempStr+ temp +"</div>"); 
  }

  
 

}
