import { Component, OnDestroy, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SkyToastService, SkyToastType } from "@skyux/toast";
import { contacts } from "../modals/contacts";
import { groups } from "../modals/groups";
import { ContactService } from "../service/contact.service";
import { GroupService } from "../service/group.service";
import { CampaignService } from "../service/campaign.service";
import { CampaignListPopupComponent } from "./campaign-list-popup.component";
import {
  SkyAutocompleteSearchFunctionFilter,
  SkyAutocompleteSelectionChange
} from '@skyux/lookup';
import { SkyModalService } from "@skyux/modals";
import { campaigns } from "../modals/campaigns";
import { Title } from "@angular/platform-browser";
@Component({
  selector: 'app-manage-campaign',
  templateUrl: './manage-campaign.component.html',
  styleUrls: ['./manage-campaign.component.scss']
})
export class ManageCampaignComponent  implements OnInit, OnDestroy {
 
  constructor(
    public  toastService: SkyToastService,
    public fb: FormBuilder,
    private contactService: ContactService,
    private groupService: GroupService,
    private campaignService: CampaignService,
    private modal: SkyModalService,
    private titleService: Title,
  ) { 
    this.loadFormGroup();
  }


  ngOnInit(): void {
    this.titleService.setTitle("Campaigns - Contact Management System");
    this.getGroupsData()
    this.getContactsData(0, 0, 0, 0);
  }

  ngOnDestroy(): void {
    
  }
 

  public options: any[] = [
    { name: 'Contact', value: '1', disabled: false },
    { name: 'Group', value: '2', disabled: false }
  ];
  public CampaignForm: FormGroup;
  DefaultCampaignEmailTemplate: string = '<p><img alt="Test RRS" src="https://www.nagarro.com/hs-fs/hubfs/Nagarro-Sep2016-Theme/Images/Webinar-2018_Connected_Enterprise/Nagarro-logo-269.jpg?width=269&name=Nagarro-logo-269.jpg" style="height:80px; width:300px" /></p><p>Dear&nbsp;<strong>{contactname}</strong>,</p><h3 style="color:#92987e;"><strong>We are excited to welcome you into our family of Nagarrians !!!!</strong></h3><p>Our guiding principles can be defined by one word &ndash; CARING. This denotes a humanistic, people-first way of thinking and nurturing, and a strong emphasis on ethics. Caring guides us as a global company, but we act locally to affect change where it is most needed and relevant to where we are.&nbsp;</p><p><strong>Nagarro &quot;CARING&quot;</strong></p><ul><li><strong>C&nbsp;</strong>=&nbsp;Client-centric</li><li><strong>A&nbsp;</strong>=&nbsp;Agile</li><li><strong>R&nbsp;</strong>=&nbsp;Responsible</li><li><strong>I&nbsp;</strong>=&nbsp;Intelligent</li><li><strong>N&nbsp;</strong>=&nbsp;Non-hierarchical</li><li><strong>G&nbsp;</strong>=&nbsp;Global</li></ul><p><strong>Topics we care about:</strong></p><ul style="list-style-type:square;"><li>Inclusion and Diversity</li><li>Sustainability</li><li>Gender Equality</li><li>Better Society</li><li>Clean Air</li><li>Work Life Balance&nbsp;</li><li>Bridging Distances</li><li>Road Safety</li></ul><p>&nbsp;</p><p><strong>Regards,</strong></p><p><strong>Nagarro Software</strong></p>';
  campaignEmailTemplate: string = '<p><img alt="Test RRS" src="https://www.nagarro.com/hs-fs/hubfs/Nagarro-Sep2016-Theme/Images/Webinar-2018_Connected_Enterprise/Nagarro-logo-269.jpg?width=269&name=Nagarro-logo-269.jpg" style="height:80px; width:300px" /></p><p>Dear&nbsp;<strong>{contactname}</strong>,</p><h3 style="color:#92987e;"><strong>We are excited to welcome you into our family of Nagarrians !!!!</strong></h3><p>Our guiding principles can be defined by one word &ndash; CARING. This denotes a humanistic, people-first way of thinking and nurturing, and a strong emphasis on ethics. Caring guides us as a global company, but we act locally to affect change where it is most needed and relevant to where we are.&nbsp;</p><p><strong>Nagarro &quot;CARING&quot;</strong></p><ul><li><strong>C&nbsp;</strong>=&nbsp;Client-centric</li><li><strong>A&nbsp;</strong>=&nbsp;Agile</li><li><strong>R&nbsp;</strong>=&nbsp;Responsible</li><li><strong>I&nbsp;</strong>=&nbsp;Intelligent</li><li><strong>N&nbsp;</strong>=&nbsp;Non-hierarchical</li><li><strong>G&nbsp;</strong>=&nbsp;Global</li></ul><p><strong>Topics we care about:</strong></p><ul style="list-style-type:square;"><li>Inclusion and Diversity</li><li>Sustainability</li><li>Gender Equality</li><li>Better Society</li><li>Clean Air</li><li>Work Life Balance&nbsp;</li><li>Bridging Distances</li><li>Road Safety</li></ul><p>&nbsp;</p><p><strong>Regards,</strong></p><p><strong>Nagarro Software</strong></p>';
  private loadFormGroup(): void {
    this.CampaignForm = this.fb.group({
      campaignName: ['', [Validators.required]],
      emailSubject: ['', [Validators.required]],
      group: [''],
      contactId: {},
      campType: this.options[0].name,
    });

  }

  save(){
      console.log(this.campaignEmailTemplate);
  }

  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.CampaignForm.controls[controlName];
    if (!control) {
      return false;
    }

    const result = control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }
  groupsData: groups[] = [];
  getGroupsData() {
    this.groupsData = [];
    this.groupService.getAllGroups()
      .subscribe(res => {
        this.groupsData = res;
        setTimeout(() => {
          this.isWaiting = false;
          }, 1000);
      },
      err => {
        setTimeout(() => {
          this.isWaiting = false;
          }, 1000);
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
  }

  contactsData: contacts[] = [];
  isWaiting: boolean = false;
  getContactsData(isRecentTop: number, isBlock: number, isImp: number, isActive: number) {
    this.contactsData = [];
    let payload = {
      "IsRecentTop": isRecentTop,
      "IsBlocked": isBlock,
      "IsImportant": isImp,
      "IsActive": isActive
    }
    this.isWaiting = true;
    this.contactService.getAllContacts(payload)
      .subscribe(res => {
        this.contactsData = res;
        setTimeout(() => {
          this.isWaiting = false;
          }, 1000);
      },
        err => {
          setTimeout(() => {
            this.isWaiting = false;
            }, 1000);
          this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
        })
  }
  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  public searchFilters: SkyAutocompleteSearchFunctionFilter[] = [
    (searchText: string, item: any): boolean => {
      return (item.name !== 'Red');
    }
  ];

  public onContactSelection(args: SkyAutocompleteSelectionChange): void {
    // alert(`You selected ${args.selectedItem.name}`);
  }

  isContactSelected: boolean = true;
  campTypeOnChange(obj:any){
    if(obj.value == 1){
      this.isContactSelected = true;
    }else if(obj.value == 2){
      this.isContactSelected = false;
    }
  }
  RunCampaign()
  {
    const controls = this.CampaignForm.controls;
    /** check form */
    if (this.CampaignForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );
      this.openToast("Required mandatory fields", SkyToastType.Warning);
      return;
    }
    if(!this.campaignEmailTemplate ){
      this.openToast("Required mandatory fields", SkyToastType.Warning);
      return;
    }
    if( !this.isContactSelected && !(this.CampaignForm.value.group && this.CampaignForm.value.group>0) ){
      this.openToast("Group is Required", SkyToastType.Warning);
      return;
    }
    if(this.isContactSelected && !(this.CampaignForm.value.contactId && this.CampaignForm.value.contactId.id >0) ){
      this.openToast("Contact is Required", SkyToastType.Warning);
      return;
    }
    let payload = {
      "CampaignName": this.CampaignForm.value.campaignName,
      "EmailSubject":this.CampaignForm.value.emailSubject,
      "EmailTemplate": this.campaignEmailTemplate,
      "GroupId": this.CampaignForm.value.group ? +this.CampaignForm.value.group : 0,
      "ContactId": this.CampaignForm.value.contactId && this.CampaignForm.value.contactId.id > 0 ? 
                                                      +this.CampaignForm.value.contactId.id : 0
    }
    this.isWaiting = true;
    this.campaignService.RunEmailCampaign(payload)
    .subscribe(res => {
      if (res && res.isSuccess) {
        this.openToast(res.message, SkyToastType.Success);
        this.ResetCampaign();
      } else {
        this.openToast(res.message, SkyToastType.Danger);
      }
      this.isWaiting = false;
    }, err => {
      this.isWaiting = false;
      this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
    })
  }

  ResetCampaign(){
    this.CampaignForm.reset();
    this.CampaignForm.get('campType').setValue(this.options[0].name);
    this.isContactSelected = true;
    this.campaignEmailTemplate = this.DefaultCampaignEmailTemplate;
  }


  public helpKey: string = 'help-demo.html';
  public modalSize: string = 'large';
  public openCampaignListPopUp(): void {
    const modalInstanceType: any = CampaignListPopupComponent;
    const options: any = {
      helpKey: this.helpKey,
      size: this.modalSize
    };
    this.modal.open(modalInstanceType, options);

  }

  campaignDetails: campaigns[] = [];
  onOpenModalClick() : void{
    this.campaignDetails =[];
    this.campaignService.getAllCampaignDetails()
    .subscribe(res => {
      if (res) {
        this.campaignDetails = res;
        this.campaignService.shareCampaignsDataList({
          "campaignsData": this.campaignDetails
        });
        this.openCampaignListPopUp();
      } 

    }, err => {
      this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
    })
  }
}
