import {
  NgModule
} from '@angular/core';

import {
  AppSkyModule
} from './app-sky.module';
// import {AppFooterComponent} from './shared/app-footer.component'
@NgModule({
  exports: [
    AppSkyModule,
    // AppFooterComponent
  ],
  declarations: [
    // AppFooterComponent
  ],
  entryComponents: [
   
  ],
  providers: [
   
  ],
})
export class AppExtrasModule { }
