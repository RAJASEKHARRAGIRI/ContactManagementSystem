import {
  Component
} from '@angular/core';
import {  SkyModalInstance } from '@skyux/modals';
import { SkyToastService, SkyToastType } from '@skyux/toast';
import { ContactService } from '../service/contact.service';


@Component({
  selector: 'app-contact-list-popup',
  templateUrl: './contact-list-popup.component.html',
  styleUrls: ['./contact-list-popup.component.scss']
})
export class ContactListPopupComponent {

  constructor(
    public instance: SkyModalInstance,
    private contactService: ContactService,
    private toastService: SkyToastService,
   
  ) { 
    this.data =  JSON.parse(localStorage.getItem("contactsData"))
    this.selectedKeyword =  +JSON.parse(localStorage.getItem("currentKeyword"))
  }
  data:any[] = [];
  selectedKeyword : number = 0;
  ngOnInit() {
    
  }

  closePopup(){
    this.instance.close()
  }

 
  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  getContactInfo(contactId :number){
    let obj = this.data.filter(c => c.id == contactId)[0];
    console.log(obj);
    let payload={
      "ContactId": obj.id,
      "Keyword": +this.selectedKeyword
    }
    this.contactService.updateSpeedDialContact(payload)
    .subscribe(res => {
      if (res && res.isSuccess) {
        this.openToast(res.message, SkyToastType.Success);
        this.instance.close();
        this.contactService.afterCompleteOperationKnowTheSpeedDialStatus({
          "isSuccess": true
        })
      } else {
        this.openToast(res.message, SkyToastType.Danger);
      }

    }, err => {
      this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
    })
  }
 

}
