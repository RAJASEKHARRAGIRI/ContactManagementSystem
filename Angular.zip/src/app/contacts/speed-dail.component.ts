import {
  Component
} from '@angular/core';
import { SkyModalService } from '@skyux/modals';
import { SkyToastService, SkyToastType } from '@skyux/toast';
import { speedDialContacts } from '../modals/contacts';
import { ContactService } from '../service/contact.service';

import {ContactListPopupComponent} from './contact-list-popup.component'
@Component({
  selector: 'app-speed-dail',
  templateUrl: './speed-dail.component.html',
  styleUrls: ['./speed-dail.component.scss']
})
export class SpeedDailComponent {
  speedDialRowData = ["row1","row2","row3"];
  speedDialArray = {
    "row1": [
      {"keyword": "1"},
      {"keyword": "2"},
      {"keyword": "3"}
    ],
    "row2": [
      {"keyword": "4"},
      {"keyword": "5"},
      {"keyword": "6"}
    ],
    "row3": [
      {"keyword": "7"},
      {"keyword": "8"},
      {"keyword": "9"}
    ]
  }

  constructor(
    private toastService: SkyToastService,
    private modal: SkyModalService,
    private contactService: ContactService,
  ) {
    this.getSpeedDialContactsData();
    this.getContactsData();
    

    //know current opertaion status
    this.contactService.contactSpeedDialStatus.subscribe(value => {
      if (value.isSuccess){
        this.getSpeedDialContactsData();
      }
    });
  }

  speedDialContactsData:speedDialContacts[] =[];
  getSpeedDialContactsData() {
    this.speedDialContactsData=[];
   this.isWaiting = true;
    this.contactService.getAllSpeedDialContacts()
      .subscribe(res => {
       console.log("sp",res);
       this.speedDialContactsData = res;
        setTimeout(() => {
          this.isWaiting = false;
        }, 1000);
      },
      err=>{
        setTimeout(() => {
          this.isWaiting = false;
        }, 1000);
        this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
      });
  }

  getContactInfo(keyId: any, propertyName: string){
   
    let obj = this.speedDialContactsData.filter(c => c.keyword == keyId);
    // console.log("HH",obj)
    if(propertyName == 'name')
      return obj[0].name;
    else if(propertyName == 'email')
      return obj[0].email;
    else if(propertyName == 'phone')
      return obj[0].phoneNumber;
    else if(propertyName == 'group')
      return obj[0].groupName;
    else if(propertyName == 'rel')
      return obj[0].relationship;
    else if(propertyName == 'createon')
      return obj[0].createdOn;
      
  }


  isWaiting:boolean = false;
  getContactsData() {
    let payload = {
      "IsRecentTop": 0,
      "IsBlocked": 0,
      "IsImportant": 0,
      "IsActive": 1
    }

   this.isWaiting = true;
    this.contactService.getAllContacts(payload)
      .subscribe(res => {
        localStorage.setItem("contactsData", JSON.stringify(res));
        setTimeout(() => {
          this.isWaiting = false;
        }, 1000);
      },
      err=>{
        setTimeout(() => {
          this.isWaiting = false;
        }, 1000);
        this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
      });
  }

  
  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  public helpKey: string = 'help-demo.html';
  public modalSize: string = 'large';
  public onOpenModalClick(keyword: number): void {
    const modalInstanceType1: any = ContactListPopupComponent;
    const options: any = {
      helpKey: this.helpKey,
      size: this.modalSize
    };
    localStorage.setItem("currentKeyword",keyword.toString())
    this.modal.open(modalInstanceType1, options);

  }
}
