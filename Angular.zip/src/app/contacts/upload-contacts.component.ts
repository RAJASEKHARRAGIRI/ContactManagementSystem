import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from '@angular/forms';

import * as XLSX from 'ts-xlsx';
import {
  Component,
  OnInit
} from '@angular/core';

import {
  // SkyFileAttachmentChange,
  SkyFileAttachmentClick,
  // SkyFileItem
} from '@skyux/forms';
import {
  SkyConfirmService,
  SkyModalInstance
} from '@skyux/modals';
import { SkyToastService, SkyToastType } from '@skyux/toast';
import { GroupService } from '../service/group.service';
import { ContactService } from '../service/contact.service';
import { groups } from '../modals/groups';
// import { variable } from '@angular/compiler/src/output/output_ast';
// import { contacts } from '../modals/contacts';
// import { groups } from '../modals/groups';
// import { ContactService } from '../service/contact.service';
// import { GroupService } from '../service/group.service';

@Component({
  selector: 'app-upload-contacts',
  templateUrl: './upload-contacts.component.html',
  styleUrls: ['./upload-contacts.component.scss']
})
export class UploadContactsComponent implements OnInit{
  
  constructor(
    public instance: SkyModalInstance,
    public confirmService: SkyConfirmService,
    private toastService: SkyToastService,
    private formBuilder: FormBuilder,
    private contactService: ContactService,
    private groupService: GroupService,
  ) { 
    this.getGroupsData();
  }

  groupsData: groups[] = [];
  getGroupsData() {
    this.groupsData = [];
    this.groupService.getAllGroups()
      .subscribe(res => {
        this.groupsData = res;
      },
      err => {
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
  }

  public attachment: FormControl;

  public fileForm: FormGroup;

  public maxFileSize: number = 4000000;

  public get reactiveFile(): AbstractControl {
    return this.fileForm.get('attachment');
  }

  public reactiveUploadError: string;

  public fileClick($event: SkyFileAttachmentClick): void {
    const link = document.createElement('a');
    link.download = $event.file.file.name;
    link.href = $event.file.url;
    link.click();
  }

  public ngOnInit(): void {
    this.attachment = new FormControl(undefined, Validators.required);
    this.fileForm = this.formBuilder.group({
      attachment: this.attachment
    });
  }

  closePopup(){
    this.instance.close()
    // this.contactService.afterCompleteOperationKnowTheStatus({
    //   "isSuccess": true
    // });
  }

  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  // arrayBuffer:any;
  saveContact(contactData: any){
    let payload = {
      "Id": 0,
      "Name": contactData.name,
      "Email": contactData.email,
      "PhoneNumber": contactData.phonenumber+"",
      "Relationship": contactData.relationship,
      "Description":contactData.desc ,
      "GroupId": +contactData.group,
      "IsBlocked": contactData.isBlock,
      "IsImportant": contactData.isImp
    }

      this.contactService.addContact(payload)
        .subscribe(res => {
          this.totalRequestsCount++;
          this.calPercentage = (this.totalRequestsCount / this.totalUploadedCount) * 100
          if (res && !res.isSuccess) {
            this.failedCount++;
            this.openToast(res.message, SkyToastType.Danger);
          }
          if(this.totalUploadedCount == this.totalRequestsCount){
            this.openToast((this.totalUploadedCount - this.failedCount)+" Contacts Successfully Uploaded, "+ this.failedCount
            +" Contacts failed", SkyToastType.Success);
            this.isWaiting = false;
          }
        }, err => {
          this.failedCount++;
          if(this.totalUploadedCount == this.totalRequestsCount){
            this.openToast((this.totalUploadedCount - this.failedCount)+" Contacts Successfully Uploaded, "+ this.failedCount
            +" Contacts failed", SkyToastType.Info);
            this.isWaiting = false;
          }
          this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
        })
    
  }

  arrayBuffer: any;
  file: File;
  incomingfile(event:any) {
    this.file = event.target.files[0];
  }

  isWaiting: boolean = false;
  contactExcelArr: excelObj[] =[];
  failedCount=0;
  totalUploadedCount=0;
  totalRequestsCount=0;
  calPercentage=0;
  Upload() {
    this.calPercentage=0;
    this.failedCount=0;
    this.totalRequestsCount=0;
    this.totalUploadedCount=0;
    let fileReader = new FileReader();
    fileReader.onload = (e) => {
      this.arrayBuffer = fileReader.result;
      var data = new Uint8Array(this.arrayBuffer);
      var arr = new Array();
      for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");
      var workbook = XLSX.read(bstr, { type: "binary" });
      var first_sheet_name = workbook.SheetNames[0];
      var worksheet = workbook.Sheets[first_sheet_name];
      console.log(XLSX.utils.sheet_to_json(worksheet, { raw: true }));
      
      this.contactExcelArr = <excelObj[]> XLSX.utils.sheet_to_json(worksheet, { raw: true });
      this.totalUploadedCount =this.contactExcelArr.length;
      for(let i=0;i<this.totalUploadedCount; i++){
        this.isWaiting = true;
        let contact = this.contactExcelArr[i];
        let requestPayload = {
          'name': contact.Name,
          "email": contact.Email,
          "phonenumber": contact.MobileNumber,
          "relationship": contact.Relationship.toLowerCase(),
          "desc": contact.Description,
          "group": this.getGroupInfo(contact.Group),
          "isBlock": contact.IsBlock=="No" ? 0 : 1,
          "isImp": contact.IsImportant=="No" ? 0 : 1
        }
        this.saveContact(requestPayload);
      };
     
      
    }
    fileReader.readAsArrayBuffer(this.file);
  }

  getGroupInfo(name: string){
    let obj = this.groupsData.filter(g => g.name.toLowerCase() == name.toLowerCase())[0];
    return obj && obj.id> 0 ? obj.id : 7;
  }
}


interface excelObj {
  Description: string
  Email: string
  Group: string
  IsBlock: string
  IsImportant: string
  MobileNumber: string
  Name: string
  Relationship: string
}