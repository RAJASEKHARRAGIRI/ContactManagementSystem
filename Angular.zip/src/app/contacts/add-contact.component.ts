import {
  Component
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  SkyConfirmService,
  SkyModalInstance
} from '@skyux/modals';
import { SkyToastService, SkyToastType } from '@skyux/toast';
import { contacts } from '../modals/contacts';
import { groups } from '../modals/groups';
import { ContactService } from '../service/contact.service';
import { GroupService } from '../service/group.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.scss']
})
export class AddContactComponent {
  constructor(
    public instance: SkyModalInstance,
    public confirmService: SkyConfirmService,
    private toastService: SkyToastService,
    private contactService: ContactService,
    private groupService: GroupService,
    private fb: FormBuilder,
  ) { 
    console.log(instance);
    this.loadFormGroup();
    this.getGroupsData()
    this.getContactsData(0, 0, 0, 0);
  }
  modalTitle: string = "Add Contact";

  public splitViewDemoForm: FormGroup;
  private loadFormGroup(): void {
    this.splitViewDemoForm = this.fb.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required]],
      phonenumber: ['', [Validators.required]],
      relationship: ['', [Validators.required,  Validators.min(1)]],
      group: ['', [Validators.required, Validators.min(1)]],
      desc: [],
      isblock: [false],
      isimportant:[false],
    });

  }

  isUpdate: boolean = false;
  contactObj: contacts =<contacts>{};
  ngOnInit() {
    this.modalTitle = "Add Contact"
    this.contactService.contactOpertationStatus.subscribe(value => {
      if(value.isUpdate){
        this.contactObj = value.contactObject;
        this.isUpdate = true;
        this.modalTitle = "Update Contact";
        this.splitViewDemoForm.get('name').setValue(this.contactObj.name);
        this.splitViewDemoForm.get('email').setValue(this.contactObj.email);
        this.splitViewDemoForm.get('phonenumber').setValue(this.contactObj.phoneNumber);
        this.splitViewDemoForm.get('relationship').setValue(this.contactObj.relationship.toLowerCase());
        this.splitViewDemoForm.get('group').setValue(this.contactObj.groupId);
        this.splitViewDemoForm.get('desc').setValue(this.contactObj.description);
        this.splitViewDemoForm.get('isblock').setValue(this.contactObj.isBlocked);
        this.splitViewDemoForm.get('isimportant').setValue(this.contactObj.isImportant);
        
      }
    });
  }

  contactsData: contacts[] = [];
  isWaiting: boolean = true;
  getContactsData(isRecentTop: number, isBlock: number, isImp: number, isActive: number) {
    this.contactsData = [];
    let payload = {
      "IsRecentTop": isRecentTop,
      "IsBlocked": isBlock,
      "IsImportant": isImp,
      "IsActive": isActive
    }
    this.isWaiting = true;
    this.contactService.getAllContacts(payload)
      .subscribe(res => {
        this.contactsData = res;
        if(this.isUpdate){
          this.onGroupChange(+this.contactObj.groupId)
        }
      },
        err => {
          this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
        })
  }

   groupsData: groups[] = [];
  getGroupsData() {
    this.groupsData = [];
    this.groupService.getAllGroups()
      .subscribe(res => {
        this.groupsData = res;
      
      },
      err => {
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
  }
 

  saveContact(): void {
    const controls = this.splitViewDemoForm.controls;
    /** check form */
    if (this.splitViewDemoForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );
      this.openToast("Required mandatory fields", SkyToastType.Warning);
      return;
    }
    if (!this.groupHaveSpace) {
      this.openToast("Selected group don't have space to add new contact, please select another group", SkyToastType.Danger);
      return;
    }
    let payload = {
      "Id": this.isUpdate ? this.contactObj.id : 0,
      "Name": this.splitViewDemoForm.value.name,
      "Email": this.splitViewDemoForm.value.email,
      "PhoneNumber": this.splitViewDemoForm.value.phonenumber,
      "Relationship": this.splitViewDemoForm.value.relationship,
      "Description": this.splitViewDemoForm.value.desc +"",
      "GroupId": +this.splitViewDemoForm.value.group,
      "IsBlocked": this.splitViewDemoForm.value.isblock ? 1 : 0,
      "IsImportant": this.splitViewDemoForm.value.isimportant ? 1 : 0
    }

    if (this.isUpdate) 
    {
      this.contactService.updateContact(payload)
        .subscribe(res => {
          if (res && res.isSuccess) {
            this.openToast(res.message, SkyToastType.Success);
            this.instance.close();
            this.isUpdate = false;
            this.contactService.afterCompleteOperationKnowTheStatus({
              "isSuccess": true
            });
          } else {
            this.openToast(res.message, SkyToastType.Danger);
          }

        }, err => {
          this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
        })
    } 
    else 
    {
      this.contactService.addContact(payload)
        .subscribe(res => {
          if (res && res.isSuccess) {
            this.openToast(res.message, SkyToastType.Success);
            this.instance.close();
            this.contactService.afterCompleteOperationKnowTheStatus({
              "isSuccess": true
            });
          } else {
            this.openToast(res.message, SkyToastType.Danger);
          }

        }, err => {
          this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
        })
    }

  }


  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.splitViewDemoForm.controls[controlName];
    if (!control) {
      return false;
    }

    const result = control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }

  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  closePopup(){
    this.instance.close()
    this.contactService.afterCompleteOperationKnowTheStatus({
      "isSuccess": true
    });
  }

  groupLeftContactsTextCount: string ="";
  groupHaveSpace: boolean = false;
  onGroupChange(groupId: any){
    this.groupLeftContactsTextCount ="";
    this.groupHaveSpace = false;
    if(groupId && groupId >0){
      let objContact = this.contactsData.filter(c =>c.groupId == groupId);
      let obj = this.groupsData.filter(g => g.id == groupId)[0];
      this.groupLeftContactsTextCount = "Only "+ (obj.maxLimit - objContact.length) + " more contacts";
      if(objContact.length < obj.maxLimit )
        this.groupHaveSpace = true;
    }
  }
}
