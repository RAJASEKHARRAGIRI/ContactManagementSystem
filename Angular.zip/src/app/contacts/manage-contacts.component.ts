import { Component, HostListener, OnInit } from '@angular/core';
// import { FormBuilder } from '@angular/forms';
// import { SkyWaitService } from '@skyux/indicators';
import { ListSortFieldSelectorModel } from '@skyux/list-builder-common';
import { SkyConfirmService } from '@skyux/modals';
import { SkyToastService, SkyToastType } from '@skyux/toast';
import { BehaviorSubject, of } from 'rxjs';
import {
  take
} from 'rxjs/operators';
import { contacts } from '../modals/contacts';
import { ContactService } from '../service/contact.service';
import { UploadContactsComponent } from '../contacts/upload-contacts.component';

import {
  SkyModalService
} from '@skyux/modals';

import {
  AddContactComponent
} from './add-contact.component';
import { groups } from '../modals/groups';
import { GroupService } from '../service/group.service';
import { Title } from '@angular/platform-browser';
@Component({
  selector: 'app-manage-contacts',
  templateUrl: './manage-contacts.component.html',
  styleUrls: ['./manage-contacts.component.scss']
})
export class ManageContactsComponent implements OnInit {
  public asyncHeading = new BehaviorSubject<string>('');
  
  constructor(
    public confirmService: SkyConfirmService,
    private titleService: Title,
    private toastService: SkyToastService,
    private contactService: ContactService,
    private modal: SkyModalService,
    private groupService: GroupService,
    // private fb: FormBuilder,
  ) {
    // this.waitSvc.beginBlockingPageWait();
    // setTimeout(() => {
    //   this.waitSvc.endBlockingPageWait();
    // }, 10);

    //know current opertaion status
    this.contactService.contactOpertationStatus.subscribe(value => {
      if (value.isSuccess){
        this.clearSearch();
        this.getData(0, 0, 0, 0);
      }
    });
  }

  public ngOnInit(): void {
    this.titleService.setTitle("Contacts - Contact Management System");
    // Simulate async request:
    setTimeout(() => {
      this.asyncHeading.next('Mobilenumber');
    }, 1000);
    this.getGroupsData();
    this.getData(0, 0, 0, 0);
    
   
  }

  groupsData: groups[] = [];
  getGroupsData() {
    this.groupsData = [];
    this.groupService.getAllGroups()
      .subscribe(res => {
        this.groupsData = res;
      },
      err => {
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
  }

  getGroupInfo(groupId: number,propertyName: string){
    // console.log("Iam");
      let obj = this.groupsData.filter(obj => obj.id == groupId);
      if(propertyName == 'name')
        return obj[0].name;
      else if(propertyName == 'des')
        return obj[0].description;
      else if(propertyName == 'limit')
        return obj[0].maxLimit;
     
  }

  getContactInfo(contactId: number,propertyName: string){
    
      let obj = this.mainContactsData.filter(obj => obj.id == contactId);
      // console.log("Iam", obj);
      if (propertyName == 'block')
        return obj[0].isBlocked == 1 ? true : false;
      else if (propertyName == 'important')
        return obj[0].isImportant == 1 ? true : false;
  }


  mainContactsData: contacts[] = [];
  contactsData: contacts[] = [];
  isWaiting: boolean = true;
  getData(isRecentTop: number, isBlock: number, isImp: number, isActive: number) {
    this.contactsData = [];
    this.mainContactsData = [];
    let payload = {
      "IsRecentTop": isRecentTop,
      "IsBlocked": isBlock,
      "IsImportant": isImp,
      "IsActive": isActive
    }
    this.isWaiting = true;
    this.contactService.getAllContacts(payload)
      .subscribe(res => {
        this.contactsData = res;
        this.mainContactsData = res;
        console.log(this.contactsData);
        this.clearSearch();
        setTimeout(() => {
          this.isWaiting = false;
          this.gotoTop();
        }, 1000);
      },
        err => {
          setTimeout(() => {
            this.isWaiting = false;
          }, 1000);
          this.openToast("Status Code: " + err.status + ", " + err.message, SkyToastType.Danger);
        })
  }

  public openToast(message: string, msgType: SkyToastType): void {
    this.toastService.openMessage(message, {
      type: msgType
    });
    // setTimeout(function() { this.toastService.closeAll();}, 5000);
  }

  public onSortChangeForGrid(activeSort: ListSortFieldSelectorModel): void {
    this.contactsData = this.sortGridData(activeSort, this.contactsData);
  }

  private sortGridData(activeSort: ListSortFieldSelectorModel, data: any[]): any[] {
    const sortField = activeSort.fieldSelector;
    const descending = activeSort.descending;

    return data.sort((a: any, b: any) => {
      let value1 = a[sortField];
      let value2 = b[sortField];

      if (value1 && typeof value1 === 'string') {
        value1 = value1.toLowerCase();
      }

      if (value2 && typeof value2 === 'string') {
        value2 = value2.toLowerCase();
      }

      if (value1 === value2) {
        return 0;
      }

      let result = value1 > value2 ? 1 : -1;

      if (descending) {
        result *= -1;
      }

      return result;
    }).slice();
  }

  //list
  public items = of([
    { id: '1', column1: 100, column2: 'All Contacts', column3: 'All saved contact', keyword: 'all' },
    { id: '2', column1: 101, column2: 'Active Contacts', column3: 'Regularly using contact numbers', keyword: 'active' },
    { id: '3', column1: 202, column2: 'Blocked Contacts', column3: 'Blocked the mobile number', keyword: 'block' },
    { id: '4', column1: 303, column2: 'Recent Logs', column3: 'Recent used top 10 contacts', keyword: 'recent' },
    { id: '5', column1: 404, column2: 'Important', column3: 'Mark as a important contact', keyword: 'important' },
    { id: '6', column1: 505, column2: 'Speed Dial', column3: 'Press single button to use contact', keyword: 'speeddial' },
    // { id: '7', column1: 505, column2: 'Export', column3: 'Export to PDF, Xlx, etc.', keyword: 'export' }
  ]);

  public selectedItems: any[] = [];
  public selectMode = 'single'; //multiple
  isSpeedDail: boolean = false;
  public selectedItemsChange(selectedMap: Map<string, boolean>): void {
    this.isSpeedDail = false;
    this.items.pipe(take(1)).subscribe((items) => {
      this.selectedItems = items.filter(item => selectedMap.get(item.id));
    });
    let recent = 0, blocked = 0, imp = 0, act = 0;
    if (this.selectedItems[0].keyword == 'recent')
      recent = 1;
    else if (this.selectedItems[0].keyword == 'block')
      blocked = 1;
    else if (this.selectedItems[0].keyword == 'important')
      imp = 1;
    else if (this.selectedItems[0].keyword == 'active')
      act = 1;

    if (this.selectedItems[0].keyword == "export" || this.selectedItems[0].keyword == "speeddial") {
      this.contactsData = [];
      // this.openToast("Working inprogress", SkyToastType.Danger);
      this.isSpeedDail =true;
    }
    else {
      this.isSpeedDail =false;
      this.getData(recent, blocked, imp, act);
    }

  }

  //dropdown
  public DDitems: any[] = [
    { name: 'Option 1', disabled: false },
    { name: 'Disabled option', disabled: true },
    { name: 'Option 3', disabled: false },
    { name: 'Option 4', disabled: false },
    { name: 'Option 5', disabled: false }
  ];

  public actionClicked(action: string): void {
    alert(`You selected ${action}.`);
  }

  public helpKey: string = 'help-demo.html';
  public modalSize: string = 'medium';
  public onOpenModalClick(contactId: any, operation: string): void {
    const modalInstanceType: any = AddContactComponent;
    const options: any = {
      helpKey: this.helpKey,
      size: this.modalSize
    };
    let flag = operation == 'update' ? true : false;
    let currentObj = this.contactsData.filter(obj => obj.id == contactId)[0];
    this.contactService.afterCompleteOperationKnowTheStatus({
      "isUpdate": flag,
      "contactObject": currentObj
    });
    this.modal.open(modalInstanceType, options);

  }

  deleteContact(contactId: any){
    if (confirm('Are you sure you want to delete this contact?')) {
      this.contactService.deleteContactOnId(+contactId)
      .subscribe(res => {
        if(res && res.isSuccess ){
          this.openToast(res.message, SkyToastType.Success);
        }else{
          this.openToast(res.message, SkyToastType.Danger);
        }
        this.getData(0, 0, 0, 0);
      }, err => {
        this.openToast("Status Code: "+err.status+", " + err.message, SkyToastType.Danger);
      })
    } else {
      return;
    }
  }

  gotoTop(){
    window.scroll({ 
      top: 0, 
      left: 0, 
      behavior: 'smooth' 
    });
  }

  isShow: boolean;
  topPosToStartShowing = 20;

  @HostListener('window:scroll')
  checkScroll() {
    // Both window.pageYOffset and document.documentElement.scrollTop returns the same result in all the cases. window.pageYOffset is not supported below IE 9.
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    // console.log('[scroll]', scrollPosition);
    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  searchName: string ="";
  groupSearch: string ="";
  SearchContacts(){
    this.contactsData =[];
    if(this.searchName == "" && this.groupSearch ==""){
      this.contactsData = this.mainContactsData;
        return
    }
   
    this.contactsData = this.mainContactsData.filter(o =>
      Object.keys(o).some(k => (o.name.toLowerCase().includes(this.searchName.toLowerCase()) && 
                           (this.groupSearch =="" ? true : o.groupId == +this.groupSearch )) ));
  }

  clearSearch(){
    this.searchName="";
    this.groupSearch="";
    this.contactsData = this.mainContactsData;
  }


  public helpKey1: string = 'help-demo.html';
  public modalSize1: string = 'medium';
  public onOpenUploadModalClick(): void {
    const modalInstanceType: any = UploadContactsComponent;
    const options: any = {
      helpKey: this.helpKey1,
      size: this.modalSize1
    };
   
    // this.contactService.afterCompleteOperationKnowTheStatus({
    //   "isUpdate": flag,
    //   "contactObject": currentObj
    // });
    this.modal.open(modalInstanceType, options);

  }
}
