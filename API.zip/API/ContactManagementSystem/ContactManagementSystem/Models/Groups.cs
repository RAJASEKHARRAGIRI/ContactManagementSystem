﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Models
{
    public class Groups
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int MaxLimit { get; set; }
        public string Comments { get; set; }
    }

    public class GetGroups : Groups
    {
        public string CreatedOn { get; set; }
    }
}
