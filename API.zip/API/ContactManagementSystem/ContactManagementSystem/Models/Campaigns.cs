﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Models
{
    public class Campaigns
    {
        public string CampaignName { get; set; }
        public string EmailSubject { get; set; }
        public string EmailTemplate { get; set; }
        public int GroupId { get; set; }
        public int ContactId { get; set; }
    }

    public class GetAllCampaigns
    {
        public int CampaignId { get; set; }
        public string CampaignName { get; set; }
        public int CampaignType { get; set; }
        public int ContactId { get; set; }
        public string ContactName { get; set; }
        public string  ContactEmail { get; set; }
        public string  PhoneNumber { get; set; }
        public string GroupName { get; set; }
        public string EmailSubject { get; set; }
        public string EmailTemplate { get; set; }
        public int EmailIsSent { get; set; }
        public string CampaignRunOn { get; set; }
    }
}
