﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Models
{
    public class EmailTemplate
    {
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }
        public string ToEmail { get; set; }
        public string ToEmailContactName { get; set; }
        
    }
}
