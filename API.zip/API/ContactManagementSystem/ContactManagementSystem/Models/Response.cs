﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Models
{
    public class Response
    {
        public bool IsSuccess { get; set; }
        public string Errors { get; set; }
        public string Message { get; set; }
    }
}
