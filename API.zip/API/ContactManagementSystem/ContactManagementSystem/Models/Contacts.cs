﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Models
{
    public class Contacts
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Relationship { get; set; }
        public string Description { get; set; }
        public int GroupId { get; set; }
        public int IsBlocked { get; set; }
        public int IsImportant { get; set; }
    }

    public class GetContacts : Contacts
    {
        public string CreatedOn { get; set; }
        public string GroupDescription { get; set; }
        public string GroupName { get; set; }
        public int GroupMaxLimit { get; set; }
        public string GroupComments { get; set; }
    }

    public class GetSpeedDialContacts : GetContacts
    {
        public int Keyword { get; set; }
    }

    public class GetContactsRequest 
    {
        public int IsBlocked { get; set; }
        public int IsImportant { get; set; }
        public int IsRecentTop { get; set; }
        public int IsActive { get; set; }
    }


    public class SpeedDialUpdateRequest
    {
        public int ContactId { get; set; }
        public int Keyword { get; set; }
    }



}
