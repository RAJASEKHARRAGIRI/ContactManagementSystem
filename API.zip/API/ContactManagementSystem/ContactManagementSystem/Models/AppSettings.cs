using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;

namespace NetCoreAPI.Models.AppConfigurations
{
    public class AuthSettings
    {
        public string SecretKey { get; set; }
    }

    public class DatabaseConfiguration : IDisposable
    {
        public  SqlConnection Connection { get; }

        public DatabaseConfiguration (string connectionString)
        {
            Connection = new SqlConnection(connectionString);
        }

        public void Dispose () => Connection.Dispose();
    }
}