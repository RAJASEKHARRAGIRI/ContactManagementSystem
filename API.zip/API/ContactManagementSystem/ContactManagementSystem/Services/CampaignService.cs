﻿using ContactManagementSystem.DataProviders;
using ContactManagementSystem.Helpers;
using ContactManagementSystem.Interfaces;
using ContactManagementSystem.Models;
using Microsoft.Extensions.Options;
using NetCoreAPI.Models.AppConfigurations;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Services
{
    public class CampaignService : ICampaign
    {
        private CampaignData _campaignData = null;
        private EmailSendingService _emailSendingService = null;
        internal DatabaseConfiguration _database { get; set; }
        public CampaignService(DatabaseConfiguration dbConfigurations, IOptions<ApplicationIdentitySettings> applicationIdentitySettings)
        {
            _campaignData = new CampaignData(dbConfigurations);
            _database = dbConfigurations;
            _emailSendingService = new EmailSendingService(dbConfigurations, applicationIdentitySettings);
        }

        public Task<Response> RunCampaign(Campaigns camp)
        {
            Response returnObj = null;
            List<GetContacts> contactList = GetCampaignData(camp);
            if (contactList.Count > 0)
            {
               
                foreach (var contact in contactList)
                {
                    EmailTemplate email = new EmailTemplate()
                    { 
                        EmailBody = camp.EmailTemplate,
                        ToEmail = contact.Email,
                        EmailSubject = camp.EmailSubject,
                        ToEmailContactName = contact.Name
                    };
                   var res  =  _emailSendingService.SendMailUsingSMTP(email);
                   returnObj = JsonConvert.DeserializeObject<Response>(JsonConvert.SerializeObject(res.Result));
                    camp.EmailTemplate = email.EmailBody;
                    camp.ContactId = contact.Id;
                    _campaignData.InsertCampaignDetails(camp, returnObj);
                }
            }
           
            return Task.FromResult(returnObj);
        }

       

        public List<GetContacts> GetCampaignData(Campaigns camp)
        {
            List<GetContacts> contactList = new List<GetContacts>();
            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "GetContactDetailsOnGroupIdOrContactId";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_contactId", SqlDbType.Int).Value = camp.ContactId;
                    command.Parameters.Add("@_groupId", SqlDbType.Int).Value = camp.GroupId;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            contactList.Add(new GetContacts()
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Name = Convert.ToString(reader["contactName"]),
                                Email = Convert.ToString(reader["Email"]),
                                PhoneNumber = Convert.ToString(reader["PhoneNumber"]),
                                Relationship = Convert.ToString(reader["Relationship"]),
                                Description = Convert.ToString(reader["contactDesc"]),
                                GroupId = Convert.ToInt32(reader["groupId"]),
                                GroupName = Convert.ToString(reader["groupName"]),
                                IsBlocked = Convert.ToInt32(reader["IsBlocked"]),
                                IsImportant = Convert.ToInt32(reader["IsImportant"]),
                                CreatedOn = Convert.ToString(reader["CreatedOn"]),
                                GroupDescription = Convert.ToString(reader["groupDesc"]),
                                GroupMaxLimit = Convert.ToInt32(reader["MaxLimit"]),
                                GroupComments = Convert.ToString(reader["Comments"]),
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return contactList;
        }

        public Task<List<GetAllCampaigns>> GetAllCampaignDetails()
        {
            return _campaignData.GetAllCampaignDetails();
        }
    }
}
