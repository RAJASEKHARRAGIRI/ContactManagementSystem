﻿using ContactManagementSystem.DataProviders;
using ContactManagementSystem.Interfaces;
using ContactManagementSystem.Models;
using Microsoft.Extensions.Options;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Services
{
    public class GroupsService : IGroups
    {
        private GroupsData _groupsData = null;
        public GroupsService(DatabaseConfiguration dbConfigurations)
        {
            _groupsData = new GroupsData(dbConfigurations);
        }

        public Task<bool> AddGroup(Groups group)
        {
            return _groupsData.AddGroup(group);
        } 
        public Task<bool> UpdateGroup(Groups group)
        {
            return _groupsData.UpdateGroup(group);
        }
        public Task<List<GetGroups>> GetAllGroups()
        {
            return _groupsData.GetAllGroups();
        }
        public Task<bool> DeleteGroup(int groupId)
        {
            return _groupsData.DeleteGroup(groupId);
        }

       
    }
}
