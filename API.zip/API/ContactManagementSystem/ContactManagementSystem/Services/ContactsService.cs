﻿using ContactManagementSystem.DataProviders;
using ContactManagementSystem.Interfaces;
using ContactManagementSystem.Models;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Services
{
    public class ContactsService : IContacts
    {
        private ContactsData _contactsData = null;
        public ContactsService(DatabaseConfiguration dbConfigurations)
        {
            _contactsData = new ContactsData(dbConfigurations);
        }

        public Task<bool> AddContact(Contacts contact)
        {
            return _contactsData.AddContact(contact);
        }
        public Task<bool> UpdateContact(Contacts contact)
        { 
            return _contactsData.UpdateContact(contact);
        }
        public Task<List<GetContacts>> GetAllContacts(GetContactsRequest request)
        {
            return _contactsData.GetAllContacts(request);
        }
        public Task<bool> DeleteContact(int contactId)
        {
            return _contactsData.DeleteContact(contactId);
        }

        public Task<List<GetSpeedDialContacts>> GetAllSpeedDialContacts()
        {
            return _contactsData.GetAllSpeedDialContacts();
        }

        public Task<bool> UpdateSpeedDialContact(SpeedDialUpdateRequest contact)
        {
            return _contactsData.UpdateSpeedDialContact(contact);
        }


    }
}
