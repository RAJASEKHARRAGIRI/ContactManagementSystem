﻿using ContactManagementSystem.Models;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.DataProviders
{
    public class CampaignData
    {
        internal DatabaseConfiguration _database { get; set; }
        public CampaignData(DatabaseConfiguration databaseConfiguration)
        {
            _database = databaseConfiguration;
        }

        public async Task<List<GetContacts>> GetAllContacts(GetContactsRequest request)
        {
            List<GetContacts> groupsList = new List<GetContacts>();

            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "GetAllContactDetails";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_isBlocked", SqlDbType.Int).Value = request.IsBlocked;
                    command.Parameters.Add("@_isImp", SqlDbType.Int).Value = request.IsImportant;
                    command.Parameters.Add("@_recentTop", SqlDbType.Int).Value = request.IsRecentTop;
                    command.Parameters.Add("@_isActive", SqlDbType.Int).Value = request.IsActive;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            groupsList.Add(new GetContacts()
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Name = Convert.ToString(reader["contactName"]),
                                Email = Convert.ToString(reader["Email"]),
                                PhoneNumber = Convert.ToString(reader["PhoneNumber"]),
                                Relationship = Convert.ToString(reader["Relationship"]),
                                Description = Convert.ToString(reader["contactDesc"]),
                                GroupId = Convert.ToInt32(reader["groupId"]),
                                GroupName = Convert.ToString(reader["groupName"]),
                                IsBlocked = Convert.ToInt32(reader["IsBlocked"]),
                                IsImportant = Convert.ToInt32(reader["IsImportant"]),
                                CreatedOn = Convert.ToString(reader["CreatedOn"]),
                                GroupDescription = Convert.ToString(reader["groupDesc"]),
                                GroupMaxLimit = Convert.ToInt32(reader["MaxLimit"]),
                                GroupComments = Convert.ToString(reader["Comments"]),
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return await Task.FromResult(groupsList);
        }

        public void InsertCampaignDetails(Campaigns campData, Response emailResponse)
        {
            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "AddCampaignDetails";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_campName", SqlDbType.VarChar).Value = campData.CampaignName;
                    command.Parameters.Add("@_emailSubject", SqlDbType.VarChar).Value = campData.EmailSubject;
                    command.Parameters.Add("@_campType", SqlDbType.Int).Value = campData.GroupId > 0 ? 2 : 1;
                    command.Parameters.Add("@_contactId", SqlDbType.Int).Value = campData.ContactId;
                    command.Parameters.Add("@_emailTemplate", SqlDbType.VarChar).Value = campData.EmailTemplate;
                    command.Parameters.Add("@_emailSent", SqlDbType.Int).Value = emailResponse.IsSuccess ? 1 :0;
                    command.Parameters.Add("@_errorMessage", SqlDbType.VarChar).Value = emailResponse.Message;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                //throw;
            }
        }

        public async Task<List<GetAllCampaigns>> GetAllCampaignDetails()
        {
            List<GetAllCampaigns> campaigns = new List<GetAllCampaigns>();
            string commandText = @"SELECT  camp.Id ,camp.CampaignName ,camp.EmailSubject  ,camp.CampaignType ,camp.ContactId ,c.Name as ContactName "
                                    +" ,c.Email ,c.PhoneNumber ,g.Name as GroupName ,camp.EmailTemplate ,camp.EmailSent ,camp.CreatedOn"
                                    + " FROM dbo.Trans_CampaignDetails camp INNER JOIN dbo.Trans_Contacts c ON c.Id = camp.ContactId"
                                    + " LEFT JOIN dbo.Trans_ContactGroups g ON g.Id = c.GroupId Order By camp.CreatedOn desc;";
            using (var connection = _database.Connection)
            {
                if (_database.Connection.State == System.Data.ConnectionState.Closed)
                    _database.Connection.Open();
                using (var tran = connection.BeginTransaction())
                {
                    using (var command = new SqlCommand(commandText, connection, tran))
                    {
                        try
                        {
                            command.CommandTimeout = 300;
                            using (SqlDataReader rdr = command.ExecuteReader())
                            {
                                while (rdr.Read())
                                {
                                    GetAllCampaigns campaign = new GetAllCampaigns();
                                    campaign.CampaignId = Convert.ToInt32(rdr["Id"].ToString());
                                    campaign.CampaignName = Convert.ToString(rdr["CampaignName"].ToString());
                                    campaign.EmailSubject = Convert.ToString(rdr["EmailSubject"].ToString());
                                    campaign.CampaignType = Convert.ToInt32(rdr["CampaignType"].ToString());
                                    campaign.ContactId = Convert.ToInt32(rdr["ContactId"].ToString());
                                    campaign.ContactName = Convert.ToString(rdr["ContactName"].ToString());
                                    campaign.ContactEmail = Convert.ToString(rdr["Email"].ToString());
                                    campaign.PhoneNumber = Convert.ToString(rdr["PhoneNumber"].ToString());
                                    campaign.GroupName = Convert.ToString(rdr["GroupName"].ToString());
                                    campaign.EmailTemplate = Convert.ToString(rdr["EmailTemplate"].ToString());
                                    campaign.EmailIsSent = Convert.ToInt32(rdr["EmailSent"].ToString());
                                    campaign.CampaignRunOn = Convert.ToString(rdr["CreatedOn"].ToString());
                                    campaigns.Add(campaign);
                                }
                            }
                        }
                        catch (Exception Ex)
                        {
                            throw;
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
            }
            return await Task.FromResult(campaigns);
        }

    }
}
