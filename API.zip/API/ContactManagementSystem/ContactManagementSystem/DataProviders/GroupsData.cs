﻿using ContactManagementSystem.Models;
using IdentityModel.Client;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.DataProviders
{
    public class GroupsData
    {
        internal DatabaseConfiguration _database { get; set; }
        public GroupsData(DatabaseConfiguration databaseConfiguration)
        {
            _database = databaseConfiguration;
        }

        public async Task<bool> AddGroup(Groups group)
        {
            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "AddUpdateContactGroup";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_autoId", SqlDbType.Int).Value = group.Id;
                    command.Parameters.Add("@_name", SqlDbType.VarChar).Value = group.Name;
                    command.Parameters.Add("@_desc", SqlDbType.VarChar).Value = group.Description;
                    command.Parameters.Add("@_comm", SqlDbType.VarChar).Value = group.Comments;
                    command.Parameters.Add("@_maxlimit", SqlDbType.Int).Value = group.MaxLimit;
                    command.Parameters.Add("@_isUpdate", SqlDbType.Int).Value = 0;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateGroup(Groups group)
        {
            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "AddUpdateContactGroup";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_autoId", SqlDbType.Int).Value = group.Id;
                    command.Parameters.Add("@_name", SqlDbType.VarChar).Value = group.Name;
                    command.Parameters.Add("@_desc", SqlDbType.VarChar).Value = group.Description;
                    command.Parameters.Add("@_comm", SqlDbType.VarChar).Value = group.Comments;
                    command.Parameters.Add("@_maxlimit", SqlDbType.Int).Value = group.MaxLimit;
                    command.Parameters.Add("@_isUpdate", SqlDbType.Int).Value = 1;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return await Task.FromResult(true);
        }

        public async Task<List<GetGroups>> GetAllGroups()
        {
            List<GetGroups> groups = new List<GetGroups>();
            string commandText = @"SELECT * FROM Trans_ContactGroups ORDER BY Name;";
            using (var connection = _database.Connection)
            {
                if (_database.Connection.State == System.Data.ConnectionState.Closed)
                    _database.Connection.Open();
                using (var tran = connection.BeginTransaction())
                {
                    using (var command = new SqlCommand(commandText, connection, tran))
                    {
                        try
                        {
                            command.CommandTimeout = 300;
                            using (SqlDataReader rdr = command.ExecuteReader())
                            {
                                while (rdr.Read())
                                {
                                    GetGroups group = new GetGroups();
                                    group.Id = Convert.ToInt32(rdr["Id"].ToString());
                                    group.Name = Convert.ToString(rdr["Name"].ToString());
                                    group.Description = Convert.ToString(rdr["Description"].ToString());
                                    group.Comments = Convert.ToString(rdr["Comments"].ToString());
                                    group.MaxLimit = Convert.ToInt32(rdr["MaxLimit"].ToString());
                                    group.CreatedOn = Convert.ToString(rdr["CreatedOn"].ToString());
                                    groups.Add(group);
                                }
                            }
                        }
                        catch (Exception Ex)
                        {
                            throw;
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
            }
            return await Task.FromResult(groups);
        }

        public async Task<bool> DeleteGroup(int groupId)
        {
            string commandText = @"DELETE FROM Trans_ContactGroups WHERE Id = "+ groupId;
            using (var connection = _database.Connection)
            {
                if (_database.Connection.State == System.Data.ConnectionState.Closed)
                    _database.Connection.Open();
                using (var command = new SqlCommand(commandText, connection))
                {
                    try
                    {
                        command.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        throw;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            return await Task.FromResult(true);
        }
    }
}
