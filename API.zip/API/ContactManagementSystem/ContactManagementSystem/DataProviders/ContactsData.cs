﻿using ContactManagementSystem.Models;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.DataProviders
{
    public class ContactsData
    {
        internal DatabaseConfiguration _database { get; set; }
        public ContactsData(DatabaseConfiguration databaseConfiguration)
        {
            _database = databaseConfiguration;
        }

        public async Task<bool> AddContact(Contacts contact)
        {
            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "AddUpdateContactDetails";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_autoId", SqlDbType.Int).Value = contact.Id;
                    command.Parameters.Add("@_name", SqlDbType.VarChar).Value = contact.Name;
                    command.Parameters.Add("@_email", SqlDbType.VarChar).Value = contact.Email;
                    command.Parameters.Add("@_phone", SqlDbType.VarChar).Value = contact.PhoneNumber;
                    command.Parameters.Add("@_relation", SqlDbType.VarChar).Value = contact.Relationship;
                    command.Parameters.Add("@_desc", SqlDbType.VarChar).Value = contact.Description;
                    command.Parameters.Add("@_groupId", SqlDbType.Int).Value = contact.GroupId;
                    command.Parameters.Add("@_isBlocked", SqlDbType.Int).Value = contact.IsBlocked;
                    command.Parameters.Add("@_isImp", SqlDbType.Int).Value = contact.IsImportant;
                    command.Parameters.Add("@_isUpdate", SqlDbType.Int).Value = 0;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateContact(Contacts contact)
        {
            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "AddUpdateContactDetails";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_autoId", SqlDbType.Int).Value = contact.Id;
                    command.Parameters.Add("@_name", SqlDbType.VarChar).Value = contact.Name;
                    command.Parameters.Add("@_email", SqlDbType.VarChar).Value = contact.Email;
                    command.Parameters.Add("@_phone", SqlDbType.VarChar).Value = contact.PhoneNumber;
                    command.Parameters.Add("@_relation", SqlDbType.VarChar).Value = contact.Relationship;
                    command.Parameters.Add("@_desc", SqlDbType.VarChar).Value = contact.Description;
                    command.Parameters.Add("@_groupId", SqlDbType.Int).Value = contact.GroupId;
                    command.Parameters.Add("@_isBlocked", SqlDbType.Int).Value = contact.IsBlocked;
                    command.Parameters.Add("@_isImp", SqlDbType.Int).Value = contact.IsImportant;
                    command.Parameters.Add("@_isUpdate", SqlDbType.Int).Value = 1;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return await Task.FromResult(true);
        }

        public async Task<List<GetContacts>> GetAllContacts(GetContactsRequest request)
        {
            List<GetContacts> groupsList = new List<GetContacts>();

            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "GetAllContactDetails";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_isBlocked", SqlDbType.Int).Value = request.IsBlocked;
                    command.Parameters.Add("@_isImp", SqlDbType.Int).Value = request.IsImportant;
                    command.Parameters.Add("@_recentTop", SqlDbType.Int).Value = request.IsRecentTop;
                    command.Parameters.Add("@_isActive", SqlDbType.Int).Value = request.IsActive;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            groupsList.Add(new GetContacts()
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Name = Convert.ToString(reader["contactName"]),
                                Email = Convert.ToString(reader["Email"]),
                                PhoneNumber = Convert.ToString(reader["PhoneNumber"]),
                                Relationship = Convert.ToString(reader["Relationship"]),
                                Description = Convert.ToString(reader["contactDesc"]),
                                GroupId = Convert.ToInt32(reader["groupId"]),
                                GroupName = Convert.ToString(reader["groupName"]),
                                IsBlocked = Convert.ToInt32(reader["IsBlocked"]),
                                IsImportant = Convert.ToInt32(reader["IsImportant"]),
                                CreatedOn = Convert.ToString(reader["CreatedOn"]),
                                GroupDescription = Convert.ToString(reader["groupDesc"]),
                                GroupMaxLimit = Convert.ToInt32(reader["MaxLimit"]),
                                GroupComments = Convert.ToString(reader["Comments"]),
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return await Task.FromResult(groupsList);
        }

        public async Task<bool> DeleteContact(int contactId)
        {
            string commandText = @"DELETE FROM Trans_Contacts WHERE Id = " + contactId;
            using (var connection = _database.Connection)
            {
                if (_database.Connection.State == System.Data.ConnectionState.Closed)
                    _database.Connection.Open();
                using (var command = new SqlCommand(commandText, connection))
                {
                    try
                    {
                        command.ExecuteNonQuery();
                    }
                    catch (Exception Ex)
                    {
                        throw;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            return await Task.FromResult(true);
        }
        public async Task<List<GetSpeedDialContacts>> GetAllSpeedDialContacts()
        {
            List<GetSpeedDialContacts> contactList = new List<GetSpeedDialContacts>();

            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "GetAllSpeedDialDetails";

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            contactList.Add(new GetSpeedDialContacts()
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Name = Convert.ToString(reader["contactName"]),
                                Email = Convert.ToString(reader["Email"]),
                                PhoneNumber = Convert.ToString(reader["PhoneNumber"]),
                                Relationship = Convert.ToString(reader["Relationship"]),
                                Description = Convert.ToString(reader["contactDesc"]),
                                GroupId = Convert.ToInt32(reader["groupId"]),
                                GroupName = Convert.ToString(reader["groupName"]),
                                IsBlocked = Convert.ToInt32(reader["IsBlocked"]),
                                IsImportant = Convert.ToInt32(reader["IsImportant"]),
                                CreatedOn = Convert.ToString(reader["CreatedOn"]),
                                GroupDescription = Convert.ToString(reader["groupDesc"]),
                                GroupMaxLimit = Convert.ToInt32(reader["MaxLimit"]),
                                GroupComments = Convert.ToString(reader["Comments"]),
                                Keyword = Convert.ToInt32(reader["Keyword"])
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return await Task.FromResult(contactList);
        }

        public async Task<bool> UpdateSpeedDialContact(SpeedDialUpdateRequest contact)
        {
            try
            {
                using (var command = _database.Connection.CreateCommand())
                {
                    if (_database.Connection.State == System.Data.ConnectionState.Closed)
                        _database.Connection.Open();
                    command.CommandText = "UpdateSpeedDialContact";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@_contactId", SqlDbType.Int).Value = contact.ContactId;
                    command.Parameters.Add("@_keyword", SqlDbType.Int).Value = contact.Keyword;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return await Task.FromResult(true);
        }
    }
}
