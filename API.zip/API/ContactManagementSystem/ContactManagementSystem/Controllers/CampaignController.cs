﻿using ContactManagementSystem.Interfaces;
using ContactManagementSystem.Models;
using ContactManagementSystem.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CampaignController : ControllerBase
    {
        private readonly ICampaign _camp;
        private DatabaseConfiguration _configuration { get; set; }
        private readonly ApplicationIdentitySettings _applicationIdentitySettings;
        public CampaignController(DatabaseConfiguration configuration, IOptions<ApplicationIdentitySettings> applicationIdentitySettings)
        {
            _configuration = configuration;
            _applicationIdentitySettings = applicationIdentitySettings.Value;
            _camp = new CampaignService(configuration, applicationIdentitySettings);
        }


        
        [HttpPost("RunCampaign")]
        public async Task<IActionResult> RunCampaign([FromBody] Campaigns camp)
        {
            Response res = await _camp.RunCampaign(camp);
            if (res.IsSuccess)
            {
                return Ok(new Response() { IsSuccess = true, Errors = null, Message = "Email Campaign Successfully Completed" });
            }
            return BadRequest(new Response() { IsSuccess = false, Errors = res.Message, Message = "Error occur while running email campaign." });
        }

        [HttpGet("GetAllCampaignDetails")]
        public async Task<IActionResult> GetAllCampaignDetails()
        {
            return Ok(await _camp.GetAllCampaignDetails());
        }
    }
}
