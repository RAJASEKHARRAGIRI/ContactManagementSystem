﻿using ContactManagementSystem.Interfaces;
using ContactManagementSystem.Models;
using ContactManagementSystem.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupsController : ControllerBase
    {
        private readonly IGroups _groups;
        private DatabaseConfiguration _configuration { get; set; }
        public GroupsController( DatabaseConfiguration configuration)
        {
            _configuration = configuration;
            _groups = new GroupsService(configuration);
        }


        [HttpPost("AddGroup")]
        public async Task<IActionResult> AddGroup([FromBody] Groups groups)
        {
            var res = await _groups.AddGroup(groups);
            if (res)
            {
                return Ok(new Response() { IsSuccess = true, Errors = null, Message = "Group Added Successfully" });
            }
            return BadRequest(new Response() { IsSuccess = false, Errors = res.ToString(), Message = "Error occur while adding group." });
        }

        [HttpPost("UpdateGroup")]
        public async Task<IActionResult> UpdateGroup([FromBody] Groups groups)
        {
            var res = await _groups.UpdateGroup(groups);
            if (res)
            {
                return Ok(new Response() { IsSuccess = true, Errors = null, Message = "Group Updated Successfully" });
            }
            return BadRequest(new Response() { IsSuccess = false, Errors = res.ToString(), Message = "Error occur while updating group." });
        }

        [HttpGet("GetAllGroup")]
        public async Task<IActionResult> GetAllGroup()
        {
           return Ok(await _groups.GetAllGroups());
        }

        [HttpDelete("DeleteGroup/{groupId}")]
        public async Task<IActionResult> DeleteGroup(int groupId)
        {
           var res = await _groups.DeleteGroup(groupId);
            if (res)
            {
                return Ok(new Response() { IsSuccess = true, Errors = null, Message = "Group Deleted Successfully" });
            }
            return BadRequest(new Response() { IsSuccess = false, Errors = res.ToString(), Message = "Error occur while deleting group." });
        }
    }
}
