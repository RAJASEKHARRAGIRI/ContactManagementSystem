﻿using ContactManagementSystem.Interfaces;
using ContactManagementSystem.Models;
using ContactManagementSystem.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactsController : ControllerBase
    {
        private readonly IContacts _contacts;
        private DatabaseConfiguration _configuration { get; set; }
        public ContactsController(DatabaseConfiguration configuration)
        {
            _configuration = configuration;
            _contacts = new ContactsService(configuration);
        }


        [HttpPost("AddContact")]
        public async Task<IActionResult> AddContact([FromBody] Contacts contacts)
        {
            var res = await _contacts.AddContact(contacts);
            if (res)
            {
                return Ok(new Response() { IsSuccess = true, Errors = null, Message = "Contact Added Successfully" });
            }
            return BadRequest(new Response() { IsSuccess = false, Errors = res.ToString(), Message = "Error occur while adding contact." });
        }

        [HttpPost("UpdateContact")]
        public async Task<IActionResult> UpdateContact([FromBody] Contacts contacts)
        {
            var res = await _contacts.UpdateContact(contacts);
            if (res)
            {
                return Ok(new Response() { IsSuccess = true, Errors = null, Message = "Contact Updated Successfully" });
            }
            return BadRequest(new Response() { IsSuccess = false, Errors = res.ToString(), Message = "Error occur while updating contact." });
        }

        [HttpPost("GetAllContacts")]
        public async Task<IActionResult> GetAllContacts(GetContactsRequest request)
        {
            return Ok(await _contacts.GetAllContacts(request));
        }

        [HttpDelete("DeleteContact/{contactId}")]
        public async Task<IActionResult> DeleteContact(int contactId)
        {
            var res = await _contacts.DeleteContact(contactId);
            if (res)
            {
                return Ok(new Response() { IsSuccess = true, Errors = null, Message = "Contact Deleted Successfully" });
            }
            return BadRequest(new Response() { IsSuccess = false, Errors = res.ToString(), Message = "Error occur while deleting contact." });
        }

        [HttpGet("GetAllSpeedDialContacts")]
        public async Task<IActionResult> GetAllSpeedDialContacts()
        {
            return Ok(await _contacts.GetAllSpeedDialContacts());
        }

        [HttpPost("UpdateSpeedDialContact")]
        public async Task<IActionResult> UpdateSpeedDialContact([FromBody] SpeedDialUpdateRequest contacts)
        {
            var res = await _contacts.UpdateSpeedDialContact(contacts);
            if (res)
            {
                return Ok(new Response() { IsSuccess = true, Errors = null, Message = "Contact Speed Dial Updated Successfully" });
            }
            return BadRequest(new Response() { IsSuccess = false, Errors = res.ToString(), Message = "Error occur while updating contact speed dial." });
        }
    }
}
