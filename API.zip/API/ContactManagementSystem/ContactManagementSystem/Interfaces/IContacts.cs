﻿using ContactManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Interfaces
{
    interface IContacts
    {
        Task<bool> AddContact(Contacts contact);
        Task<bool> UpdateContact(Contacts contact);
        Task<bool> DeleteContact(int contactId);
        Task<List<GetContacts>> GetAllContacts(GetContactsRequest request);
        Task<List<GetSpeedDialContacts>> GetAllSpeedDialContacts();
        Task<bool> UpdateSpeedDialContact(SpeedDialUpdateRequest contact);
    }
}
