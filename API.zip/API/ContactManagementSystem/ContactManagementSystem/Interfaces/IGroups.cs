﻿using ContactManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagementSystem.Interfaces
{
    interface IGroups 
    {
        Task<bool> AddGroup(Groups group);
        Task<bool> UpdateGroup(Groups group);
        Task<bool> DeleteGroup(int groupId);
        Task<List<GetGroups>> GetAllGroups();
    }
}
