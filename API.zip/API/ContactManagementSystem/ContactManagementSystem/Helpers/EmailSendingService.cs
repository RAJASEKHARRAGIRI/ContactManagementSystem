﻿using ContactManagementSystem.Models;
using Microsoft.Extensions.Options;
using MimeKit;
using NetCoreAPI.Models.AppConfigurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace ContactManagementSystem.Helpers
{
    public class EmailSendingService
    {
        private DatabaseConfiguration _database { get; set; }
        private ApplicationIdentitySettings _applicationIdentitySettings = null;
        public EmailSendingService(DatabaseConfiguration configuration, IOptions<ApplicationIdentitySettings> applicationIdentitySettings)
        {
            _database = configuration;
            _applicationIdentitySettings = applicationIdentitySettings.Value;
        }

    
        public async Task<Response> SendMailUsingSMTP(EmailTemplate sendEmail)
        {
            try
            {
                MimeMessage emailMessage = new MimeMessage();
                MailboxAddress emailFrom = new MailboxAddress(_applicationIdentitySettings.EmailSettings.FromName,
                                                                    _applicationIdentitySettings.EmailSettings.EmailId);
                // Create and build a new MailMessage object
                MailMessage message = new MailMessage();
                message.IsBodyHtml = true;
                message.From = new MailAddress(_applicationIdentitySettings.EmailSettings.EmailId, _applicationIdentitySettings.EmailSettings.FromName);
                message.To.Add(new MailAddress(sendEmail.ToEmail));
                message.Subject = sendEmail.EmailSubject;
                message.Body = sendEmail.EmailBody.Replace("{contactname}", $"{sendEmail.ToEmailContactName}");
                message.BodyEncoding = System.Text.Encoding.UTF8;
                message.IsBodyHtml = true;
                using (SmtpClient client = new SmtpClient())
                {
                    client.EnableSsl = true;
                    client.UseDefaultCredentials = true;
                    client.Host = _applicationIdentitySettings.EmailSettings.Host;
                    client.Port = _applicationIdentitySettings.EmailSettings.Port;
                    client.Credentials = new NetworkCredential(_applicationIdentitySettings.EmailSettings.EmailId, _applicationIdentitySettings.EmailSettings.Password);
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    try
                    {
                        client.Send(message);
                    }
                    catch (Exception ex)
                    {
                        return await Task.FromResult(new Response() { IsSuccess = false, Errors= "", Message = ex.Message });
                    }
                }
            }
            catch (Exception ex)
            {
                return await Task.FromResult(new Response() { IsSuccess = false, Errors = "", Message = ex.Message });
            }
            return await Task.FromResult(new Response() { IsSuccess = true, Errors = "", Message = "" });
        }
    }
}
